"""This is the Bing search engines plugin for Auto-GPT."""
import os
from typing import Any, Dict, List, Optional, Tuple, TypedDict, TypeVar
from auto_gpt_plugin_template import AutoGPTPluginTemplate
from . import e024_plugin

PromptGenerator = TypeVar("PromptGenerator")


class Message(TypedDict):
    role: str
    content: str


class AutoGPT1024Plugin(AutoGPTPluginTemplate):
    def __init__(self):
        super().__init__()
        self._name = "Auto-GPT-1024-Plugin"
        self._version = "0.1.0"
        self._description = "This pluging perform commands to 1024code agent."

    def can_handle_post_prompt(self) -> bool:
        return True

    def post_prompt(self, prompt: PromptGenerator) -> PromptGenerator:
        if os.getenv("SEARCH_ENGINE") == "e024":
            prompt.add_command(
                "",
                "e024_search",
                {"query": "<query>"},
                e024_plugin.search,
            )
        prompt.add_constraint(
            "Exclusively use chinese for the command Browser Website. Also "
            "output Thoughts, reasoning, plan and criticism in chinese"
        )
        return prompt

    def can_handle_pre_command(self) -> bool:
        return True

    def pre_command(
        self, command_name: str, arguments: Dict[str, Any]
    ) -> Tuple[str, Dict[str, Any]]:
        if command_name == "google" and os.getenv("SEARCH_ENGINE") == "e024":
            # this command does nothing but it is required to continue performing the post_command function
            return "e024_search", {"query": arguments["query"]}
        else:
            return command_name, arguments

    def can_handle_chat_completion(
        self, messages: Dict[Any, Any], model: str, temperature: float, max_tokens: int
    ) -> bool:
        return True

    def handle_chat_completion(
        self, messages: List[Message], model: str, temperature: float, max_tokens: int
    ) -> str:
        return e024_plugin.chat_completion(
            { "messages": messages, "model": model, "temperature": temperature, "max_tokens": max_tokens }
        )

    def can_handle_text_embedding(
        self, text: str, *_, **kwargs
    ) -> bool:
        return True

    def handle_text_embedding(
        self, text: str, *_, **kwargs
    ) -> list:
        return e024_plugin.text_embedding(text, **kwargs)
    
    def can_handle_post_command(self) -> bool:
        return False

    def post_command(self, command_name: str, response: str) -> str:
        pass

    def can_handle_on_planning(self) -> bool:
        return False

    def on_planning(
        self, prompt: PromptGenerator, messages: List[Message]
    ) -> Optional[str]:
        pass

    def can_handle_on_response(self) -> bool:
        return False

    def on_response(self, response: str, *args, **kwargs) -> str:
        pass

    def can_handle_post_planning(self) -> bool:
        return False

    def post_planning(self, response: str) -> str:
        pass

    def can_handle_pre_instruction(self) -> bool:
        return False

    def pre_instruction(self, messages: List[Message]) -> List[Message]:
        pass

    def can_handle_on_instruction(self) -> bool:
        return False

    def on_instruction(self, messages: List[Message]) -> Optional[str]:
        pass

    def can_handle_post_instruction(self) -> bool:
        return False

    def post_instruction(self, response: str) -> str:
        pass

    def can_handle_pre_command(self) -> bool:
        return True

    def can_handle_api_get_models(self) -> bool:
        return True

    def handle_api_get_models(self) -> list:
        return e024_plugin.get_models()

