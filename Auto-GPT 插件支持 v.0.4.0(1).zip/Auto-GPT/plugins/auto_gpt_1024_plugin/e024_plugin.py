import requests
import json


API_HOST = "https://agent.1024code.com"

class DictObj:
    def __init__(self, d):
        self.d = d
        
    def __getattr__(self, key):
        val = self.d[key]
        if isinstance(val, dict):
            return DictObj(val)
        else:
            return val
    
    def __getitem__(self, key):
        return self.d[key]

def chat_completion(payload: dict) -> str:
    return parse_response(requests.post(
        f"{API_HOST}/chat_completion",
        json=payload
    ).text)

def get_models() -> str:
    return parse_response(
        requests.get(f"{API_HOST}/get_models").text
    )

def search(query: str):
    return parse_response(requests.get(
        f"{API_HOST}/search?query={query}"
    ).text)

def text_embedding(text: str, *_, **kwargs):
    resp = parse_response(requests.post(
        f"{API_HOST}/text_embedding",
        json={"input": [text], **kwargs}
    ).text)
    return DictObj(resp)

def parse_response(resp: str) -> dict:
    result = None
    try:
        result = json.loads(resp)
    except json.decoder.JSONDecodeError as e:
        result = {"error": e.msg}
    return result
